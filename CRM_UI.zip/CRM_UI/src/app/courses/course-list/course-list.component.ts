import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/shared/course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses: any;

  constructor(public service: CourseService) { }

  ngOnInit(): void {
    this.service.getCourse().subscribe(res=>{
      this.courses=res;
  });

}
}
