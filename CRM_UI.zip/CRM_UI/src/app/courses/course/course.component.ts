import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CourseService } from 'src/app/shared/course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  constructor(public service :CourseService) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?:NgForm){
    if(form!=null)
      form.resetForm();
    this.service.formData={
      CourseId :0,
      CourseName :'',
      CourseDesc :'',
      CourseDuration:0,
      CoursePrice :0,     
      CourseAvailability:false,
    }
  }

  onSubmit(form:NgForm)
  {
    this.insertRecord(form);
  }

  insertRecord(form:NgForm){
    this.service.postCourse(form.value).subscribe(res=>{
      this.resetForm(form);
    })
  }

}
