import { Component, OnInit } from '@angular/core';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';

@Component({
  selector: 'app-resource-enquiry-list',
  templateUrl: './resource-enquiry-list.component.html',
  styleUrls: ['./resource-enquiry-list.component.css']
})
export class ResourceEnquiryListComponent implements OnInit {
  enquiries: any;

  constructor(public service: ResourceEnquiryService) { }

  ngOnInit(): void {
   
      this.service.getResourceEnquiry().subscribe(res=>{
        this.enquiries=res;
    });
  }

}

