import { Injectable } from '@angular/core';
import { ResourceEnquiry } from './resource-enquiry.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ResourceEnquiryService {

  formData: ResourceEnquiry = new ResourceEnquiry;
  readonly rootURL="https://localhost:44367/api/ResourceEnquiry";

  constructor(private http:HttpClient) { }

  postResourceEnquiry(formData:ResourceEnquiry)
  {
    alert ("Resource Enquiry Added Successfully!");
    return this.http.post(this.rootURL,formData);
  }

  getResourceEnquiry()
  {
    return this.http.get(this.rootURL);
  }
}
