
    export class CourseEnquiry {
        CourseEnquiryId:number=0;
        CourseId:number=0;
        UserName:string='';
        Email:string='';
        PhoneNo:string='';
        Dob:Date=new Date("2010-02-03");
        Qualification:string='';
        TestScore:number=0;   
        EnquiryStatus:string="Enquired"; 
    }

