import { Injectable } from '@angular/core';
import { Resource } from './resource.model';
import {HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class ResourceService {

  formData: Resource = new Resource;
  readonly rootURL="https://localhost:44367/api/Resource";

  constructor(private http:HttpClient) { }

  postResource(formData:Resource)
  {
    alert ("Resource Added Successfully!");
    return this.http.post(this.rootURL,formData);
  }

  getResource()
  {
    return this.http.get(this.rootURL);
  }
}
