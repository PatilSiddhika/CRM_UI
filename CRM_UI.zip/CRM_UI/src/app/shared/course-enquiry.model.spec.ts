import { CourseEnquiry } from './course-enquiry.model';

describe('CourseEnquiry', () => {
  it('should create an instance', () => {
    expect(new CourseEnquiry()).toBeTruthy();
  });
});
