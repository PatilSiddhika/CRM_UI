
    
    export class ResourceEnquiry {
        ResourceEnqId:number=0;
        ResourceId:number=0;
        UserName:string='';
        Email:string='';
        PhoneNo:string='';
        EnquiryStatus:string="Vacant"; 
    }



