export class Course {
    CourseId:number=0;
    CourseName:string='';
    CourseDesc:string='';
    CourseDuration:number=0;   
    CoursePrice:number=0; 
    CourseAvailability:boolean=false;
}
