import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CourseEnquiriesComponent } from './course-enquiries/course-enquiries.component';
import { CourseEnquiryComponent } from './course-enquiries/course-enquiry/course-enquiry.component';
import { CourseComponent } from './courses/course/course.component';
import { CoursesComponent } from './courses/courses.component';
import { ResourceEnquiriesComponent } from './resource-enquiries/resource-enquiries.component';
import { ResourceEnquiryComponent } from './resource-enquiries/resource-enquiry/resource-enquiry.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceesComponent } from './resourcees/resourcees.component';

const routes: Routes = [
  {path:'courses', component:CoursesComponent },
  {path:'courses/course', component:CourseComponent },
  {path:'course-enquiries', component:CourseEnquiriesComponent },
  {path:'course-enquiries/course-enquiry', component:CourseEnquiryComponent },
  {path:'resources', component:ResourceesComponent },
  {path:'resources/resource', component:ResourceComponent },
  {path:'resource-enquiries', component:ResourceEnquiriesComponent },
  {path:'resource-enquiries/resource-enquiry', component:ResourceEnquiryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
