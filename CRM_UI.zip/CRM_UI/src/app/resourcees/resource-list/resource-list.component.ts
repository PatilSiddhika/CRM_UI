import { Component, OnInit } from '@angular/core';
import { ResourceService } from 'src/app/shared/resource.service';

@Component({
  selector: 'app-resource-list',
  templateUrl: './resource-list.component.html',
  styleUrls: ['./resource-list.component.css']
})
export class ResourceListComponent implements OnInit {

  resources: any;

  constructor(public service: ResourceService) { }

  ngOnInit(): void {
    this.service.getResource().subscribe(res=>{
      this.resources=res;
  });
}


}
