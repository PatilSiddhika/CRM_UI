import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-enquiries',
  templateUrl: './course-enquiries.component.html',
  styleUrls: ['./course-enquiries.component.css']
})
export class CourseEnquiriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  

}
