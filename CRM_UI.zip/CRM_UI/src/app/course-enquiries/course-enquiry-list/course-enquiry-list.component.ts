import { Component, OnInit } from '@angular/core';
import { CourseEnquiryService } from 'src/app/shared/course-enquiry.service';


@Component({
  selector: 'app-course-enquiry-list',
  templateUrl: './course-enquiry-list.component.html',
  styleUrls: ['./course-enquiry-list.component.css']
})
export class CourseEnquiryListComponent implements OnInit {
 enquiries: any;

  constructor(public service: CourseEnquiryService) { }

  ngOnInit(): void {
    this.service.getCourseEnquiry().subscribe(res=>{
      this.enquiries=res;
  });

  
  
  }
}
